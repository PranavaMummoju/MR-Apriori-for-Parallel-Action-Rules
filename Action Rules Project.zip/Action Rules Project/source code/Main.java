package com.rules.action;

import java.io.IOException;
import java.net.URI;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.InputFormat;
import org.apache.hadoop.mapred.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Main {
	public static void main(final String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration associationActionRuleConf = new Configuration();
		Job associationActionRulesJob;
		associationActionRuleConf.setInt("Support", Integer.parseInt(args[4]));
		associationActionRuleConf.setDouble("Confidence", Double.parseDouble(args[5]));
		associationActionRulesJob = Job.getInstance(associationActionRuleConf, "Association Action Rules");
		associationActionRulesJob.setJarByClass(AssociationActionRules.class);
		associationActionRulesJob.setMapperClass(AssociationActionRules.JobMapper.class);
		associationActionRulesJob.setReducerClass(AssociationActionRules.JobReducer.class);
		// associationActionRulesJob.setNumReduceTasks(0);
		associationActionRulesJob.setOutputKeyClass(Text.class);
		associationActionRulesJob.setOutputValueClass(Text.class);
		/*
		 * Adding commmon data to all maps to the DistributedCache These
		 * contents are accessed in setup() in the Mapper class
		 */
		associationActionRulesJob.addCacheFile(new Path(args[0]).toUri());
		associationActionRulesJob.addCacheFile(new Path(args[2]).toUri());
		Path inputFilePath = new Path(args[1]);
		FileInputFormat.addInputPath(associationActionRulesJob, inputFilePath);
		FileOutputFormat.setOutputPath(associationActionRulesJob, new Path(args[3]));
		System.exit(associationActionRulesJob.waitForCompletion(true) ? 0 : 1);
	}
}